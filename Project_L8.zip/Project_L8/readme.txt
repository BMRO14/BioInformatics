Arhir Tudor
Paraschiv Vlad

the full output for ex2 is in the L8 file