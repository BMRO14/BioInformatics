Paraschiv Vlad-Andrei - 1242EEA
Ugur Kaan - 1242EEA