#Take an arbitrary DNA sequence from the NCBI between 1000-3000 nucleotides (=letters)
#Implement a software application that detects repetitions between 3b to 6b in this DNA sequence
#NOTE: Repetitive sequences refer to patterns that repeat N times (min number of repetitions is 2)
def read_fasta(filepath):
    seq_lines = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('>'):
                continue
            seq_lines.append(line)
    return ''.join(seq_lines).upper()


def find_repeats(seq, L_min=3, L_max=6, min_reps=2):
    results = []
    N = len(seq)
    seq = seq.upper()
    for L in range(L_min, L_max + 1):
        seen = {}
        for i in range(0, N - L + 1):
            pat = seq[i:i + L]
            if 'N' in pat:  # skip ambiguous nucleotides
                continue
            seen.setdefault(pat, []).append(i)
        # Check for repeats
        for pat, poslist in seen.items():
            if len(poslist) >= min_reps:
                results.append((pat, L, len(poslist), poslist))
    results.sort(key=lambda x: (-x[2], x[1], x[0]))  # sort by count desc, length, pattern
    return results


if __name__ == "__main__":
    fasta_path = "C://Users/Maria/Desktop/arbitrary_dna.fasta" 
    
    seq = read_fasta(fasta_path)
    print(f"Loaded sequence of length {len(seq)} bases.\n")

    results = find_repeats(seq, L_min=3, L_max=6, min_reps=2)
    
    print("Detected repeats (pattern, length, count, positions):\n")
    for pat, L, count, poslist in results:
        print(f"{pat}\tL={L}\tcount={count}\tpositions={poslist}")

