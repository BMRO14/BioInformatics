from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt

Entrez.email = "paraschivvla@gmail.com"

def find_repetitions(sequence, min_length=3, max_length=6, min_repeats=2):
    results = {}
    for pattern_length in range(min_length, max_length + 1):
        pattern_counts = {}
        for i in range(len(sequence) - pattern_length + 1):
            pattern = sequence[i:i + pattern_length]
            if all(base in "ACGT" for base in pattern):
                pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
        repetitive_patterns = {
            pattern: count for pattern, count in pattern_counts.items() if count >= min_repeats
        }
        if repetitive_patterns:
            results[pattern_length] = dict(
                sorted(repetitive_patterns.items(), key=lambda x: (-x[1], x[0]))
            )
    return results


def fetch_genome(accession):
    handle = Entrez.efetch(db="nuccore", id=accession, rettype="fasta", retmode="text")
    record = SeqIO.read(handle, "fasta")
    handle.close()
    return str(record.seq).upper()


def main():
    influenza_accessions = [
        "NC_007373.1", "NC_007366.1", "NC_007368.1", "NC_007371.1", "NC_007367.1",
        "NC_002017.1", "NC_002016.1", "NC_002018.1", "NC_002021.1", "NC_002020.1",
    ]

    num_genomes = len(influenza_accessions)

    fig, axes = plt.subplots(5, 2, figsize=(14, 12))
    axes = axes.flatten() 

    for ax, acc in zip(axes, influenza_accessions):
        try:
            print(f"Fetching genome {acc}...")
            seq = fetch_genome(acc)
            print(f"Analyzing genome of length {len(seq)} bases...")

            results = find_repetitions(seq, min_length=3, max_length=6, min_repeats=2)

            all_patterns, all_counts = [], []
            for length in sorted(results.keys()):
                patterns = results[length]
                for pattern, count in list(patterns.items())[:5]:
                    all_patterns.append(f"{pattern} ({length}bp)")
                    all_counts.append(count)

            ax.bar(all_patterns, all_counts, color="#74b9ff", edgecolor="black")
            ax.set_title(acc, fontsize=10)
            ax.tick_params(axis="x", labelrotation=45, labelsize=8)
            ax.set_ylabel("Count", fontsize=8)
            ax.set_xlabel("Pattern", fontsize=8)
        except Exception as e:
            print(f"❌ Error processing {acc}: {e}")
            ax.text(0.5, 0.5, f"Error loading\n{acc}", ha="center", va="center")
            ax.axis("off")

    for ax in axes[len(influenza_accessions):]:
        ax.axis("off")

    plt.suptitle("Top Repetitive Patterns (3–6 bp) in 10 Influenza Genomes", fontsize=14, weight="bold")
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()


if __name__ == "__main__":
    main()
