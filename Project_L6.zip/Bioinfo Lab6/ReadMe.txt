Paraschiv Vlad-Andrei - 1242EEA
Arhir Tudor - 1242EEA