from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt
import re, math, os, time

Entrez.email = "your_real_email@example.com"
os.makedirs("influenza_genomes", exist_ok=True)

print("Fetching up to 10 influenza virus genome records from NCBI...")
handle = Entrez.esearch(
    db="nucleotide",
    term="Influenza A virus[Organism] AND segment[Title] NOT partial",
    retmax=20
)
record = Entrez.read(handle)
ids = record["IdList"][:10]
handle.close()

if not ids:
    raise RuntimeError("No influenza genome IDs returned by NCBI. Check your email, connection, or query.")

fasta_files = []
for i, gid in enumerate(ids, start=1):
    try:
        print(f"Downloading genome {i} of {len(ids)} (NCBI ID: {gid})...")
        handle = Entrez.efetch(db="nucleotide", id=gid, rettype="fasta", retmode="text")
        seq_records = list(SeqIO.parse(handle, "fasta"))
        handle.close()
        if not seq_records:
            print(f"⚠️  Skipping genome {gid}: empty or invalid record.")
            continue
        seq_record = seq_records[0]
        file_path = f"influenza_genomes/influenza_{i}.fasta"
        SeqIO.write(seq_record, file_path, "fasta")
        fasta_files.append(file_path)
        time.sleep(0.5)  
    except Exception as e:
        print(f"❌ Error fetching {gid}: {e}")

print(f"\n✅ Successfully downloaded {len(fasta_files)} genome(s).\n")

if len(fasta_files) == 0:
    raise RuntimeError("No genomes downloaded. Cannot continue simulation.")

ecoRI_pattern = re.compile("GAATTC")

def digest_sequence(seq):
    cut_positions = [m.start() + 1 for m in ecoRI_pattern.finditer(seq)]
    if not cut_positions:
        return [len(seq)]
    positions = [0] + cut_positions + [len(seq)]
    return [positions[i+1] - positions[i] for i in range(len(positions)-1)]

def compute_migration(fragment_length, max_distance=100.0):
    return max_distance * (1.0 / math.log10(fragment_length + 10))

all_fragments = {}
all_migrations = {}

for fasta in fasta_files:
    try:
        record = SeqIO.read(fasta, "fasta")
        seq = str(record.seq).upper()
        fragments = digest_sequence(seq)
        migrations = [compute_migration(flen) for flen in fragments]
        all_fragments[fasta] = fragments
        all_migrations[fasta] = migrations
        print(f"{os.path.basename(fasta)}: {len(fragments)} EcoRI fragments")
    except Exception as e:
        print(f"⚠️  Skipping {fasta}: {e}")

plt.figure(figsize=(12, 8))
plt.gca().invert_yaxis()  
plt.gca().set_facecolor('black')
plt.title("Simulated Gel Electrophoresis of Influenza Genomes", color='white')
plt.xlabel("Genome Lane", color='white')
plt.ylabel("Migration Distance (arbitrary units)", color='white')
plt.xlim(0, len(fasta_files)+1)
plt.ylim(0, 110)

for i, fasta in enumerate(fasta_files, start=1):
    migrations = all_migrations.get(fasta, [])
    fragments = all_fragments.get(fasta, [])
    for mig, frag in zip(migrations, fragments):
        plt.plot([i-0.4, i+0.4], [mig, mig], color='cyan', linewidth=5)
        plt.text(i+0.45, mig, f"{frag}bp", color='white', fontsize=7, va='center')

plt.xticks(range(1, len(fasta_files)+1), [f"Flu{i}" for i in range(1, len(fasta_files)+1)],
           color='white', rotation=45)
plt.yticks(color='white')
plt.grid(False)
plt.tight_layout()
plt.show()

counts = {f: len(all_fragments.get(f, [])) for f in fasta_files}
sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)
print("\nGenome fragment counts (sorted):")
for f, count in sorted_counts:
    print(f"{os.path.basename(f)}: {count} fragments")
if sorted_counts:
    print(f"\nGenome with most fragments: {os.path.basename(sorted_counts[0][0])} "
          f"({sorted_counts[0][1]} fragments)")
