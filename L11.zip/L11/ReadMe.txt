Paraschiv Vlad-Andrei 
Buga Mihai
1242EEA