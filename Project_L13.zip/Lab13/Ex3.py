#use a random english text of about 300 letters(that implies spaces, punctuation) and compute the transition probabilities between words. 
#Store the transition matrix as a JSON file. 
#For ease of implementation, you can represent each new word by using a symbol of your choice(ASCII).

import random
import json

def random_english_text(target_len=300):

    words = [
        "the", "cat", "sat", "on", "the", "mat", "and", "looked", "at", "the",
        "dog", "who", "was", "running", "in", "the", "garden", "under", "a",
        "bright", "sunny", "sky", "with", "small", "white", "clouds", "."
    ]
    text = ""
    while len(text) < target_len:
        w = random.choice(words)
        if text:
            text += " "
        text += w
    return text[:target_len]

def tokenize_words(text):

    tokens = text.split()
    return tokens

def word_transition_matrix(text):
    tokens = tokenize_words(text)
    unique_tokens = sorted(set(tokens))
    index = {tok: i for i, tok in enumerate(unique_tokens)}
    n = len(unique_tokens)

    counts = [[0 for _ in range(n)] for _ in range(n)]
    for i in range(len(tokens) - 1):
        a = tokens[i]
        b = tokens[i + 1]
        counts[index[a]][index[b]] += 1

    probs = []
    for row in counts:
        s = sum(row)
        if s == 0:
            probs.append([0.0 for _ in row])
        else:
            probs.append([c / s for c in row])


    symbol_map = {tok: i for i, tok in enumerate(unique_tokens)}

    matrix_json = {
        "symbols": symbol_map,      
        "matrix": probs            
    }
    return matrix_json, text

if __name__ == "__main__":
    text = random_english_text(300)
    print("Random text:\n", text, "\n")

    word_matrix, text_used = word_transition_matrix(text)

    with open("word_transition_matrix.json", "w") as f:
        json.dump(word_matrix, f, indent=2)

    print("Word transition matrix saved to word_transition_matrix.json")
