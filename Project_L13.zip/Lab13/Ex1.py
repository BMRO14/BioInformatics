#A square matrix of an arbitrary size and the corresponding initial vector are given. 
#Implement a software application that makes a prediction on a total of 5 discrete steps, using this matrix and the corresponding vector.

import numpy as np

def predict_steps(A, x0, steps=5):

    A = np.array(A, dtype=float)
    x = np.array(x0, dtype=float)

    n, m = A.shape
    if n != m:
        raise ValueError("Matrix A must be square")
    if x.shape[0] != n:
        raise ValueError("Initial vector length must match matrix size")

    states = [x.copy()]  
    for k in range(steps):
        x = A @ x          
        states.append(x.copy())

    return states

if __name__ == "__main__":

    A = [
        [1, 0.5, 0.2],
        [0, 0.5, 0.3],
        [0, 0,   0.5]
    ]
    x0 = [10, 20, 30]

    states = predict_steps(A, x0, steps=5)

    for k, xk in enumerate(states):
        print(f"x_{k} = {xk}")
