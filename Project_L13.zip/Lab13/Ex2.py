#Use a random dna sequence of about 50 letters. use this sequence to compute the transition probabilities between letters. 
#Your output should be the transition matrix, stored as a JSON file.

import random
import json

def random_dna_sequence(length=50):
    alphabet = ['A', 'C', 'G', 'T']
    return ''.join(random.choice(alphabet) for _ in range(length))

def dna_transition_matrix(seq):
    letters = sorted(set(seq))
    index = {ch: i for i, ch in enumerate(letters)}
    n = len(letters)

    counts = [[0 for _ in range(n)] for _ in range(n)]
    for i in range(len(seq) - 1):
        a = seq[i]
        b = seq[i + 1]
        counts[index[a]][index[b]] += 1

    probs = []
    for row in counts:
        s = sum(row)
        if s == 0:
            probs.append([0.0 for _ in row])
        else:
            probs.append([c / s for c in row])

  
    matrix_json = {
        "states": letters,          
        "matrix": probs            
    }
    return matrix_json

if __name__ == "__main__":
    dna_seq = random_dna_sequence(50)
    print("DNA sequence:", dna_seq)

    dna_matrix = dna_transition_matrix(dna_seq)

    with open("dna_transition_matrix.json", "w") as f:
        json.dump(dna_matrix, f, indent=2)

    print("DNA transition matrix saved to dna_transition_matrix.json")
