Paraschiv Vlad-Andrei - 1242EEA

The results for exercises 2 and 3 are stored in the json files present in the zip file.