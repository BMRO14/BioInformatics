from collections import Counter

S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

def frequencies(sequence, n):
    sequence = sequence.upper()
    total_possible = len(sequence) - n + 1
    
    if total_possible <=0:
        return {}
        
    observed = Counter(sequence[i:i+n] for i in range (total_possible))
    
    percentages = {
        nr: (count / total_possible) * 100
        for nr, count in observed.items()
        }
    
    return dict(sorted(percentages.items()))

dinucleotide_percents = frequencies(S,2)
trinucleotide_percents = frequencies(S, 3)
    
print ("Dinucleotide Percentages: ")
for k, v in sorted (dinucleotide_percents.items()):
    print (f"{k}: {v:.2f}%")
        
print ("\n Trinucleotide Percentages: ")
for k, v in sorted (trinucleotide_percents.items()):
    print (f"{k}: {v:.2f}%")