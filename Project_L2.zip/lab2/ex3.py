import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import matplotlib.pyplot as plt
import pandas as pd

# --- Helper functions ---

def read_fasta_file(file_path):
    """Reads a FASTA file and returns the concatenated sequence as uppercase."""
    with open(file_path, 'r') as f:
        lines = f.readlines()
    seq = ''.join(line.strip() for line in lines if not line.startswith('>'))
    return seq.upper()

def sliding_window_frequencies(sequence, window_size=30):
    """Computes relative frequencies (%) of A, T, G, C in each sliding window."""
    total_windows = len(sequence) - window_size + 1
    if total_windows <= 0:
        raise ValueError("Window size is larger than sequence length.")

    data = []
    for i in range(total_windows):
        window = sequence[i:i + window_size]
        L = len(window)
        data.append({
            "Window": i + 1,
            "A (%)": round(window.count('A') / L * 100, 2),
            "T (%)": round(window.count('T') / L * 100, 2),
            "G (%)": round(window.count('G') / L * 100, 2),
            "C (%)": round(window.count('C') / L * 100, 2),
        })

    return pd.DataFrame(data)

def plot_frequencies(df, window_size):
    """Plots nucleotide frequencies as percentages."""
    plt.figure(figsize=(10, 5))
    for base in ['A (%)', 'T (%)', 'G (%)', 'C (%)']:
        plt.plot(df['Window'], df[base], label=base.split()[0])
    plt.xlabel("Window Position")
    plt.ylabel("Relative Frequency (%)")
    plt.title(f"Sliding Window ({window_size} bases)")
    plt.legend(title="Base")
    plt.grid(True, linestyle="--", alpha=0.6)
    plt.tight_layout()
    plt.show()

# --- GUI functions ---

def open_file():
    file_path = filedialog.askopenfilename(
        title="Select FASTA File",
        filetypes=[("FASTA files", "*.fasta *.fa"), ("All files", "*.*")]
    )
    if not file_path:
        return
    try:
        seq = read_fasta_file(file_path)
        messagebox.showinfo("File Loaded", f"Sequence length: {len(seq)} bases")
        analyze(seq)
    except Exception as e:
        messagebox.showerror("Error", str(e))

def analyze(sequence):
    try:
        w = int(window_size_entry.get())
        df = sliding_window_frequencies(sequence, w)
        plot_frequencies(df, w)
        show_table(df)
    except Exception as e:
        messagebox.showerror("Error", str(e))

def show_table(df):
    """Displays the first part of the DataFrame in a new scrollable table window."""
    table_window = tk.Toplevel(root)
    table_window.title("Relative Frequencies Table")
    table_window.geometry("600x400")

    frame = ttk.Frame(table_window)
    frame.pack(fill="both", expand=True)

    cols = list(df.columns)
    tree = ttk.Treeview(frame, columns=cols, show='headings')

    # Set up columns
    for col in cols:
        tree.heading(col, text=col)
        tree.column(col, anchor='center', width=100)

    # Add data (limit to first 200 rows to keep it light)
    for _, row in df.head(200).iterrows():
        tree.insert("", "end", values=list(row))

    # Add scrollbars
    vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    vsb.pack(side="right", fill="y")
    hsb.pack(side="bottom", fill="x")
    tree.pack(fill="both", expand=True)

# --- GUI layout ---

root = tk.Tk()
root.title("DNA Sliding Window Frequency Analyzer")
root.geometry("420x220")

tk.Label(root, text="🧬 DNA Sliding Window Analyzer", font=("Arial", 14, "bold")).pack(pady=10)
tk.Label(root, text="Window size (default 30):").pack()
window_size_entry = tk.Entry(root, justify='center')
window_size_entry.insert(0, "30")
window_size_entry.pack(pady=5)

tk.Button(root, text="Choose FASTA File", command=open_file,
          bg="#4CAF50", fg="white", font=("Arial", 12)).pack(pady=10)
tk.Button(root, text="Quit", command=root.destroy,
          bg="gray", fg="white", font=("Arial", 10)).pack(pady=5)

root.mainloop()
