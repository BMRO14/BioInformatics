from itertools import product

S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

def frequencies(sequence, n):
    total_possible = len(sequence) - n + 1
    counts = {}
    
    combinations = [''.join(p) for p in product('ATGC', repeat=n)]
    for combo in combinations:
        counts[combo] = 0
        
    for i in range(total_possible):
        nr = sequence[i:i+n]
        if nr in counts:
            counts[nr] += 1
            
    percentages = {k: (v / total_possible) * 100 for k,v in counts.items()}
    return percentages

dinucleotide_percents = frequencies(S, 2)
trinucleotide_percents = frequencies(S, 3)
    
print ("Dinucleotide Percentages: ")
for k, v in sorted (dinucleotide_percents.items()):
    print (f"{k}: {v:.2f}%")
        
print ("\n Trinucleotide Percentages: ")
for k, v in sorted (trinucleotide_percents.items()):
    print (f"{k}: {v:.2f}%")