import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

training_sequences = [
    
    "TAGGTACTG","TGTGTGAGT", "AAGGTAAGT", "ATGGTAACT", "CAGGTATAC", 
    "GAGGTAAAC", "TCCGTAAGT", "CAGGTTGGA", "ACAGTCAGT", "TAGGTCATT"
]

motif_length = 9
num_training = len(training_sequences)
background_prob = 0.25

counts = {nt: [0]*motif_length for nt in ['A', 'C', 'G', 'T']}
for seq in training_sequences:
    for i, nucleotide in enumerate(seq):
        counts[nucleotide][i] += 1
df_counts = pd.DataFrame(counts).T
df_counts.columns = range(1, motif_length + 1)

df_freq = df_counts / num_training
df_weights = df_freq / background_prob

with np.errstate(divide='ignore'):
    df_pwm = np.log(df_weights)

print(">>> PWM Model Re-built Successfully.\n")

influenza_genomes = {
    "Genome 1 (A/PR/8/34)":   "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 2 (A/Udorn/72)":  "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 3 (A/Korea/01)":  "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 4 (A/WSN/33)":    "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 5 (A/Cali/09)":   "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 6 (Avian H5N1)":  "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 7 (Swine H1N1)":  "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 8 (Mutant A)":    "ATGAGTCTTCTAACCGAGGTCGAAACGTACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 9 (Mutant B)":    "ATGAGTCTTCTAACCGAGGTCGAAACATACGTTCTCTCTATCGTCCCGTCAGGCCCCCTCAAAGCCGAGATCGCACAG",
    "Genome 10 (Control)":    "AAAAAAAAAACCCCCCCCCGGGGGGGGGTTTTTTTTTTAAAAAAAAACCCCCCCCCGGGGGGGGGTTTTTTTTTTTTT"
}

results = {} 

print(f"Scanning {len(influenza_genomes)} genomes\n")

for name, sequence in influenza_genomes.items():
    scores = []
    indices = []

    for i in range(len(sequence) - motif_length + 1):
        window = sequence[i : i + motif_length]
        score = 0
        possible = True
        
        for pos, nucleotide in enumerate(window):
            val = df_pwm.loc[nucleotide, pos + 1]
            if val == -np.inf:
                score = -np.inf
                possible = False
                break
            score += val
        
        if score == -np.inf:
            score = -15 
            
        scores.append(score)
        indices.append(i)
        
    results[name] = (indices, scores)

fig, axes = plt.subplots(nrows=5, ncols=2, figsize=(15, 12))
plt.subplots_adjust(hspace=0.6, wspace=0.3)
axes = axes.flatten()

for i, (name, (indices, scores)) in enumerate(results.items()):
    ax = axes[i]

    ax.plot(indices, scores, color='#2b5797', linewidth=1.5)

    ax.axhline(y=0, color='red', linestyle='--', linewidth=0.8, alpha=0.5)

    ax.set_title(name, fontsize=10, fontweight='bold')
    ax.set_ylim(-16, 10)
    ax.set_ylabel("Score")
    ax.grid(True, linestyle=':', alpha=0.6)

    max_score = max(scores)
    if max_score > -10:
        max_idx = scores.index(max_score)
        ax.annotate(f'Hit: {max_idx}\n{max_score:.1f}', 
                    xy=(max_idx, max_score), 
                    xytext=(max_idx+5, max_score+2),
                    arrowprops=dict(arrowstyle='->', color='black'),
                    fontsize=8)

plt.suptitle("Splice Site Motif Scan across 10 Influenza Genomes", fontsize=16)
plt.savefig("influenza_genome_scan.png")
print("Scan complete. Chart saved as 'influenza_genome_scan.png'.")
plt.show()