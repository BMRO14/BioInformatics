import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os


seq_S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"

sequences = [
    "TAGGTACTG", "ATGGTAACT", "CAGGTATAC", "TGTGTGAGT", "AAGGTAAGT",
    "GAGGTAAAC", "TCCGTAAGT", "CAGGTTGGA", "ACAGTCAGT", "TAGGTCATT"]

motif_length = 9
num_sequences = len(sequences)
background_prob = 0.25

print(f"parameters")
print(f"Total Sequences: {num_sequences}")
print(f"Motif Length: {motif_length}")
print(f"Background Probability: {background_prob}\n")

counts = {nt: [0]*motif_length for nt in ['A', 'C', 'G', 'T']}
for seq in sequences:
    for i, nucleotide in enumerate(seq):
        counts[nucleotide][i] += 1
df_counts = pd.DataFrame(counts).T
df_counts.columns = range(1, motif_length + 1)

df_freq = df_counts / num_sequences

df_weights = df_freq / background_prob

with np.errstate(divide='ignore'):
    df_log = np.log(df_weights)

window_data = []

for i in range(len(seq_S) - motif_length + 1):
    window = seq_S[i : i + motif_length]
    score = 0
    possible = True
 
    for pos, nucleotide in enumerate(window):
        val = df_log.loc[nucleotide, pos + 1]
        if val == -np.inf:
            score = -np.inf
            possible = False
            break
        score += val

    window_data.append({
        'Index': i,
        'Window_Sequence': window,
        'Score': score,
        'Is_Impossible': not possible
    })

df_sliding = pd.DataFrame(window_data)

print("count matrix")
print(df_counts)
print("-" * 50)

print("RELATIVE FREQUENCIES MATRIX")
print(df_freq)
print("-" * 50)

print("WEIGH MATRIX")
print(df_weights)
print("-" * 50)

print("LOG-LIKELIHOOD MATRIX")
print(df_log)
print("-" * 50)

print("SLIDING WINDOW SCORES")

print(df_sliding.to_string(formatters={'Score': lambda x: f"{x:.4f}"})) 

max_score = df_sliding.loc[df_sliding['Score'] != -np.inf, 'Score'].max()
best_row = df_sliding[df_sliding['Score'] == max_score].iloc[0]
print("\n" + "="*35)
print(f"Strongest Signal at Index {best_row['Index']}")
print(f"Sequence: {best_row['Window_Sequence']}")
print(f"Score:    {max_score:.4f}")
print("="*35 + "\n")

df_counts.to_csv("count_matrix.csv")
df_freq.to_csv("frequency_matrix.csv")
df_weights.to_csv("weigh_matrix.csv")
df_log.to_csv("log_likelihood_matrix.csv")

df_sliding.to_csv("sliding_window_scores.csv", index=False)

print(f"Files saved: count_matrix.csv, frequency_matrix.csv, weigh_matrix.csv, log_likelihood_matrix.csv, sliding_window_scores.csv")

scores = df_sliding['Score'].values
indices = df_sliding['Index'].values

finite_scores = scores[scores != -np.inf]
if len(finite_scores) > 0:
    min_finite = min(finite_scores)
    floor_value = min_finite - 5
else:
    floor_value = -10

plot_scores = [s if s != -np.inf else floor_value for s in scores]

plt.figure(figsize=(12, 6))
plt.plot(indices, plot_scores, marker='o', linestyle='-', color='#2b5797', linewidth=2, label='Score')

plt.axhline(y=floor_value + 0.5, color='red', linestyle='--', alpha=0.5, label='Impossible Threshold')

plt.title('Sliding Window Log-Likelihood Scores', fontsize=14)
plt.xlabel('Start Index', fontsize=12)
plt.ylabel('Log-Likelihood Score', fontsize=12)
plt.xticks(indices)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

if len(finite_scores) > 0:
    idx = int(best_row['Index'])
    sc = best_row['Score']
    plt.annotate(f'Peak Signal\nIndex: {idx}\nScore: {sc:.2f}', 
                 xy=(idx, sc), xytext=(idx + 2, sc - 2),
                 arrowprops=dict(facecolor='black', shrink=0.05))

plt.tight_layout()
plt.savefig('sliding_window_plot.png')
print("Plot saved: sliding_window_plot.png")
plt.show()