Paraschiv Vlad-Andrei
1242 EA