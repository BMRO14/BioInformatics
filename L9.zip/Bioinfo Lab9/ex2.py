import matplotlib.pyplot as plt
import matplotlib.patches as patches
from Bio import Entrez, SeqIO
import os
import math

Entrez.email = "vlad.paraschiv1511@stud.fils.upb.ro"

class InfluenzaRFLP_Advanced:
    def __init__(self):
        self.filename = "influenza_complete.fasta"
        self.genomes = {}
        self.raw_results = {}     
        self.filtered_results = {} 
        self.common_bands = set()

        self.enzymes = {
            "EcoRI":   {"seq": "GAATTC", "offset": 1},
            "BamHI":   {"seq": "GGATCC", "offset": 1},
            "HindIII": {"seq": "AAGCTT", "offset": 1},
            "TaqI":    {"seq": "TCGA",   "offset": 1},
            "HaeIII":  {"seq": "GGCC",   "offset": 2}
        }

    def download_data(self):
        print("--- 1. Downloading Data ---")        
        query = "Influenza A virus[Organism] AND hemagglutinin AND 1500:2500[SLEN]"
        
        try:
            handle = Entrez.esearch(db="nucleotide", term=query, retmax=10, idtype="acc")
            record = Entrez.read(handle)
            handle.close()
            id_list = record["IdList"]

            if not id_list:
                print("   > Specific search failed. Trying generic fallback...")
                handle = Entrez.esearch(db="nucleotide", term="Influenza A virus[Organism] AND 1500:2500[SLEN]", retmax=10)
                record = Entrez.read(handle)
                id_list = record["IdList"]

            if not id_list:
                raise ValueError("No sequences found on NCBI.")

            print(f"   > Downloading {len(id_list)} sequences...")
            handle = Entrez.efetch(db="nucleotide", id=id_list, rettype="fasta", retmode="text")
            data = handle.read()
            handle.close()

            with open(self.filename, "w") as f:
                f.write(data)
            print("   > Done.")

        except Exception as e:
            print(f"Error: {e}")

    def digest_genomes(self):
        if not os.path.exists(self.filename): return

        print("--- 2. Digesting Genomes ---")
        for index, record in enumerate(SeqIO.parse(self.filename, "fasta")):
            name = f"Strain {index+1}"
            seq = str(record.seq).upper()
            self.genomes[name] = seq

            cuts = []
            for enz in self.enzymes.values():
                motif = enz["seq"]
                offset = enz["offset"]
                start = 0
                while True:
                    idx = seq.find(motif, start)
                    if idx == -1: break
                    cuts.append(idx + offset)
                    start = idx + 1

            cuts = sorted(list(set(cuts)))
            bounds = [0] + cuts + [len(seq)]
            frags = [bounds[i+1]-bounds[i] for i in range(len(bounds)-1) if (bounds[i+1]-bounds[i]) > 10]
            self.raw_results[name] = sorted(frags, reverse=True)

    def identify_common_bands(self):
        if not self.raw_results: return
        
        first = True
        for frags in self.raw_results.values():
            if first:
                self.common_bands = set(frags)
                first = False
            else:
                self.common_bands = self.common_bands.intersection(set(frags))
        
        print(f"--- 3. Analysis ---")
        print(f"   > Found {len(self.common_bands)} common bands shared by ALL strains.")
        print(f"   > Sizes: {sorted(list(self.common_bands))}")

        for name, frags in self.raw_results.items():
            self.filtered_results[name] = [f for f in frags if f not in self.common_bands]

    def _draw_lane(self, ax, fragments, lane_index=0, title="", show_y_axis=True):
        ax.set_facecolor('black')

        for size in fragments:
            ax.hlines(y=size, xmin=lane_index-0.3, xmax=lane_index+0.3, color='white', linewidth=2)

        ax.add_patch(patches.Rectangle((lane_index-0.35, 3800), 0.7, 400, facecolor='#444444'))

        ax.set_yscale('log')
        ax.set_ylim(50, 4500)
        ax.set_title(title, color='black', fontsize=9, fontweight='bold')
        ax.get_xaxis().set_visible(False) # Hide X axis for individual plots
        
        if show_y_axis:
            ax.set_ylabel("bp (Log)")
        else:
            ax.get_yaxis().set_visible(False)


    def figure_1_individual_raw(self):
        if not self.raw_results: return
        
        print("--- Displaying Figure 1: Individual Raw Gels ---")

        fig, axes = plt.subplots(2, 5, figsize=(15, 8))
        fig.suptitle("FIGURE 1: Individual Gel Simulations (Raw Data)", fontsize=16)
        
        names = list(self.raw_results.keys())
        for i, ax in enumerate(axes.flat):
            if i < len(names):
                name = names[i]
                # Draw the lane centered at 0
                self._draw_lane(ax, self.raw_results[name], lane_index=0, title=name, show_y_axis=(i%5==0))
        
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()

    def figure_2_individual_filtered(self):
        if not self.filtered_results: return

        print("--- Displaying Figure 2: Individual Filtered Gels ---")
        
        fig, axes = plt.subplots(2, 5, figsize=(15, 8))
        fig.suptitle(f"FIGURE 2: Individual Gels (Common Bands Removed)\nDifferences Only", fontsize=16)
        
        names = list(self.filtered_results.keys())
        for i, ax in enumerate(axes.flat):
            if i < len(names):
                name = names[i]
                self._draw_lane(ax, self.filtered_results[name], lane_index=0, title=name, show_y_axis=(i%5==0))
                
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()

    def figure_3_merged_filtered(self):
        if not self.filtered_results: return
        
        print("--- Displaying Figure 3: Merged Differential Gel ---")
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        lanes = list(self.filtered_results.keys())

        ax.set_facecolor('black')
        ax.set_yscale('log')
        ax.set_ylim(50, 4500)

        for i, name in enumerate(lanes):
            fragments = self.filtered_results[name]

            for size in fragments:
                ax.hlines(y=size, xmin=i-0.35, xmax=i+0.35, color='white', linewidth=2.5)

            ax.add_patch(patches.Rectangle((i-0.4, 3800), 0.8, 400, facecolor='#444444'))

        ax.set_xticks(range(len(lanes)))
        ax.set_xticklabels(lanes, rotation=45, ha='right', fontsize=10, fontweight='bold')
        ax.set_ylabel("Fragment Size (bp)")
        ax.set_title("FIGURE 3: Merged Differential Electrophoresis\n(Comparative View of Unique Mutations)", fontsize=14)
        
        plt.grid(axis='y', alpha=0.3, linestyle='--')
        plt.tight_layout()
        plt.show()

app = InfluenzaRFLP_Advanced()
app.download_data()
app.digest_genomes()
app.identify_common_bands()

app.figure_1_individual_raw()      
app.figure_2_individual_filtered()  
app.figure_3_merged_filtered()     