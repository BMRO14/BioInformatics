import math
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle  # [web:62][web:64]

FASTA_PATH = 'C:/Users/Maria/Desktop/Vlad/Bioinfo/arbitrary_dna.fasta'

def read_fasta_sequence(path):
    with open(path, "r") as f:
        lines = f.readlines()
    seq_lines = [ln.strip() for ln in lines if not ln.startswith(">")]
    seq = "".join(seq_lines).upper()
    if not seq:
        raise ValueError("No sequence found in FASTA file.")
    return seq

class RestrictionEnzyme:
    def __init__(self, name, recog, cut_offset):
        self.name = name
        self.recog = recog.upper()
        self.cut_offset = cut_offset

    def digest(self, dna):
        dna = dna.upper()
        cuts = []
        start = 0
        while True:
            idx = dna.find(self.recog, start)
            if idx == -1:
                break
            cuts.append(idx + self.cut_offset)
            start = idx + 1
        return sorted(set(cuts))

enzymes = [
    RestrictionEnzyme("EcoRI",  "GAATTC", 1),
    RestrictionEnzyme("BamHI",  "GGATCC", 1),
    RestrictionEnzyme("HindIII","AAGCTT",1),
    RestrictionEnzyme("TaqI",   "TCGA",  1),
    RestrictionEnzyme("HaeIII", "GGCC",  2),
]

def fragment_lengths(seq_len, cut_positions):
    if not cut_positions:
        return [seq_len]
    cuts = [0] + sorted(cut_positions) + [seq_len]
    return [cuts[i+1] - cuts[i] for i in range(len(cuts)-1)]

def plot_gel(all_fragments):
    all_sizes = [s for frags in all_fragments.values() for s in frags]
    if not all_sizes:
        print("No fragments to plot.")
        return

    max_size = max(all_sizes)
    min_size = max(50, min(all_sizes))

    def size_to_migration(size):
        if size < min_size:
            size = min_size
        return (math.log10(max_size) - math.log10(size)) / (
            math.log10(max_size) - math.log10(min_size)
        )

    lanes = list(all_fragments.keys())
    nlanes = len(lanes)

    fig, ax = plt.subplots(figsize=(1.4 * nlanes, 6))
    ax.set_facecolor("black")

    lane_width = 0.6
    band_height = 0.02

    for lane_index, lane_name in enumerate(lanes):
        x_center = lane_index + 1
        for size in all_fragments[lane_name]:
            mig = size_to_migration(size)
            y_center = mig
            rect = Rectangle(
                (x_center - lane_width / 2, y_center - band_height / 2),
                lane_width,
                band_height,
                facecolor="white",
                edgecolor="white",
            )
            ax.add_patch(rect)

        ax.plot(
            [x_center - lane_width / 2, x_center + lane_width / 2],
            [0, 0],
            color="white",
            linewidth=3,
        )

    ax.set_xlim(0.5, nlanes + 0.5)
    ax.set_ylim(-0.05, 1.05)
    ax.invert_yaxis()
    ax.set_xticks(range(1, nlanes + 1))
    ax.set_xticklabels(lanes, rotation=45, ha="right")
    ax.set_yticks([])
    ax.set_xlabel("Restriction enzyme")
    ax.set_title("Simulated agarose gel")

    plt.tight_layout()
    plt.show()

def main():
    dna = read_fasta_sequence(FASTA_PATH)
    seq_len = len(dna)
    print(f"Loaded FASTA from: {FASTA_PATH}")
    print(f"Sequence length: {seq_len} bp")

    all_fragments = {}
    for enzyme in enzymes:
        cuts = enzyme.digest(dna)
        frags = fragment_lengths(seq_len, cuts)
        all_fragments[enzyme.name] = frags

        print(f"\nEnzyme: {enzyme.name}")
        print(f"Recognition site: {enzyme.recog}")
        print(f"Number of cleavages: {len(cuts)}")
        print("Cleavage positions (0-based):", cuts if cuts else "none")
        print("Fragment lengths (bp):", frags)

    plot_gel(all_fragments)

if __name__ == "__main__":
    main()
