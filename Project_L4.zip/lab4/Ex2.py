#Download from NCBA the FASTA files containing the COVID-19 genome, and the influenza genome. 
#Use AI to compare the codon frequencies between the 2 genomes:
#a) Make a chart that shows the top10 most frequent codons for COVID-19
#b) Make a chart that shows the top10 most frequent codons for COVID-19 influenza
#c) Compare the 2 results and show the most freq, codons above 2 genomes
#d) Show in output of console the top 3 aminoacids from each genome
#e) Formulate a promt for AI such that the three aminoacids are used most commonly to suggest food that lack on
#these aminoacids

from Bio import SeqIO
from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def count_codons(fasta_file):
    sequences = []
    for record in SeqIO.parse(fasta_file, "fasta"):
        sequences.append(str(record.seq).upper())
    seq = "".join(sequences) 
    codons = [seq[i:i+3] for i in range(0, len(seq) - 2, 3) if "N" not in seq[i:i+3]]
    return Counter(codons)

covid_codons = count_codons("covid.fasta")
flu_codons = count_codons("influenza.fasta")

df_covid = pd.DataFrame(covid_codons.most_common(10), columns=["Codon", "Frequency"])
df_flu = pd.DataFrame(flu_codons.most_common(10), columns=["Codon", "Frequency"])

plt.figure(figsize=(8, 5))
sns.barplot(data=df_covid, x="Codon", y="Frequency", palette="Blues_d")
plt.title("Top 10 Most Frequent Codons - COVID-19")
plt.show()

plt.figure(figsize=(8, 5))
sns.barplot(data=df_flu, x="Codon", y="Frequency", palette="Oranges_d")
plt.title("Top 10 Most Frequent Codons - Influenza")
plt.show()

common_codons = set(df_covid["Codon"]).intersection(set(df_flu["Codon"]))
print("\nCodons common in both genomes (Top 10 sets):", common_codons)

from Bio.Seq import Seq
def get_top_amino_acids(codon_counter):
    seq = "".join([codon * count for codon, count in codon_counter.items()])
    protein = str(Seq(seq).translate())
    aa_counts = Counter(protein)
    return aa_counts.most_common(3)

top3_covid = get_top_amino_acids(covid_codons)
top3_flu = get_top_amino_acids(flu_codons)

print("\nTop 3 amino acids (COVID-19):", top3_covid)
print("Top 3 amino acids (Influenza):", top3_flu)

def make_prompt(amino_acids):
    names = [aa[0] for aa in amino_acids]
    return f"Suggest foods that are low in these amino acids: {', '.join(names)}"

print("\nExample AI prompt (COVID-19):", make_prompt(top3_covid))
print("Example AI prompt (Influenza):", make_prompt(top3_flu))