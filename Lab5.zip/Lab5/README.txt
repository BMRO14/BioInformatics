Paraschiv Vlad-Andrei
1242EA
