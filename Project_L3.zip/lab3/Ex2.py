import math
import tkinter as tk
from tkinter import filedialog, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

# --- Tm Calculation Functions ---
def calculate_tm_basic(seq):
    """Simple formula: Tm = 4(G + C) + 2(A + T)"""
    seq = seq.upper()
    g, c, a, t = seq.count("G"), seq.count("C"), seq.count("A"), seq.count("T")
    return 4 * (g + c) + 2 * (a + t)

def calculate_tm_advanced(seq, na_conc=0.05):
    """Advanced formula: Tm = 81.5 + 16.6*log10([Na+]) + 0.41*(%GC) - 600/length"""
    seq = seq.upper()
    length = len(seq)
    gc_content = (seq.count("G") + seq.count("C")) / length * 100
    return 81.5 + 16.6 * math.log10(na_conc) + 0.41 * gc_content - (600 / length)

# --- FASTA Reader ---
def read_fasta(filename):
    """Reads a FASTA file and returns the DNA sequence."""
    with open(filename, "r") as file:
        lines = file.readlines()
    seq = "".join(line.strip() for line in lines if not line.startswith(">"))
    return seq.upper()

# --- Sliding Window Function ---
def sliding_window_tm(sequence, window_size=9):
    """Apply sliding window to calculate Tm values."""
    basic_tm_values = []
    advanced_tm_values = []
    positions = []

    for i in range(len(sequence) - window_size + 1):
        window = sequence[i:i + window_size]
        positions.append(i + 1)
        basic_tm_values.append(calculate_tm_basic(window))
        advanced_tm_values.append(calculate_tm_advanced(window))

    return positions, basic_tm_values, advanced_tm_values

# --- GUI Application ---
class DNAApp:
    def __init__(self, master):
        self.master = master
        master.title("DNA Melting Temperature Analyzer")
        master.geometry("800x600")
        master.config(bg="#f2f2f2")

        # Title
        tk.Label(master, text="DNA Melting Temperature Analyzer", 
                 font=("Helvetica", 16, "bold"), bg="#f2f2f2").pack(pady=10)

        # File selection
        tk.Button(master, text="Select FASTA File", command=self.load_file,
                  bg="#4CAF50", fg="white", font=("Arial", 12), padx=10, pady=5).pack(pady=10)

        # Label for sequence info
        self.info_label = tk.Label(master, text="", bg="#f2f2f2", font=("Arial", 11))
        self.info_label.pack(pady=5)

        # Canvas for chart
        self.canvas_frame = tk.Frame(master, bg="#f2f2f2")
        self.canvas_frame.pack(fill="both", expand=True)

    def load_file(self):
        """Handle FASTA file selection and plotting."""
        filepath = filedialog.askopenfilename(filetypes=[("FASTA files", "*.fasta *.fa *.txt")])
        if not filepath:
            return

        try:
            sequence = read_fasta(filepath)
            if len(sequence) < 9:
                messagebox.showerror("Error", "Sequence must be at least 9 bases long!")
                return

            positions, tm_basic, tm_advanced = sliding_window_tm(sequence, window_size=9)
            self.info_label.config(text=f"Loaded sequence: {len(sequence)} bases from '{filepath.split('/')[-1]}'")

            self.plot_chart(positions, tm_basic, tm_advanced)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to process file:\n{e}")

    def plot_chart(self, positions, tm_basic, tm_advanced):
        """Draw the melting temperature chart."""
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(positions, tm_basic, label="Basic Formula (4GC + 2AT)", linewidth=2)
        ax.plot(positions, tm_advanced, label="Advanced Formula", linestyle="--", linewidth=2)
        ax.set_title("Melting Temperature Along DNA Sequence (Window = 9)")
        ax.set_xlabel("Window Start Position")
        ax.set_ylabel("Melting Temperature (°C)")
        ax.legend()
        ax.grid(True)
        plt.tight_layout()

        # Clear old plot (if any)
        for widget in self.canvas_frame.winfo_children():
            widget.destroy()

        # Embed matplotlib figure in Tkinter
        canvas = FigureCanvasTkAgg(fig, master=self.canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)

# --- Run App ---
if __name__ == "__main__":
    root = tk.Tk()
    app = DNAApp(root)
    root.mainloop()
