# Use the AI to design an app that uses the sliding window methodology inorder to scan a DNA sequence from
#a fasta file, and display the melting temperature along the sequence using a chart. The chart should have
#2 signals, one for each formula. The sliding window should have 9 positions
import math

def calculate_tm (dna_sequence):
        g = dna_sequence.count("G")
        c = dna_sequence.count("C")
        a = dna_sequence.count("A")
        t = dna_sequence.count("T")
        
        tm = 4 * (g+c) + 2 * (a+t)
        return tm
    
def calculate_tm2 (dna_sequence, na = 0.05):
    length = len(dna_sequence)
    gc = (dna_sequence.count("G")+ dna_sequence.count("C")) / length * 100
    tm = 81.5 + 16.6 * math.log10(na) + 0.41 * gc - (600 / length)
    return tm

if __name__ == "__main__":
    dna_seq = input("Enter DNA sequence: ").strip()
    
    tm1 = calculate_tm(dna_seq)
    tm2 = calculate_tm2(dna_seq)
    print(f"\nDNA Sequence: {dna_seq}")
    print(f"Tm1: {tm1:.2f} celsius degrees")
    print(f"Tm2: {tm2:.2f} celsius degrees")
    